
https://bassounet.github.io/pugno/


http://localhost/pugno/

Pour le platformer voici les éléments qu'il faudrait; 

---- *-*-**-*-*-*- A FAIRE ---- **-*-*-*-*- 

- Poser platformes
- Poser des méchants
- Poser les medikits
- Poser les tono
- Poser les mines
- Poser les drones
- Poser les tourelles
- Poser les Chars 
- Poser les vehicules

- créer les backgrounds

- ECRAN ACCEUIL
- SOUND DESIGN
- """ CINEMATIQUES """"
- ECRAN DE FIN
- poser BAckground 1
- poser Background 3
- poser Background 2

- Mecanique de tir
- """ Mecanique de rentrer dans vehicule """
- Mecanique récupérer les armes
- Mecanique récupérer les medikit
- Mecanique dégâts
- Mécaniques tuer
- Les ennemis qui tirent
- à couvert !

- G.D.D

 ****-*-*-*-***-** PROCESSING ***-*-**-*-**-*-*-
 
 
 

****-----***** ICI VOYONS CE QUI A ETE FAIT ****-----*****

- DESIGN DU L.D
- implentation des cartes


- Déjà si t'as tout ça c'est bien mec en vrai c chô *******

